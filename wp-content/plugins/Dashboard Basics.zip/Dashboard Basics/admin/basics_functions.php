<?php

class basics_functions
{
    public static function basics()
    {
        require_once __DIR__ . '/Dashboard_Basics.php';
        require_once __DIR__ . '/helper.php';


    }
}

basics_functions::basics();